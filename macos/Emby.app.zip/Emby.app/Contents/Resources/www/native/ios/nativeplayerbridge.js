define([], function () {
    
    'use strict';

    const EmbyPlayer = {

        playVideo(instance, options) {
            window.MpvVideoPlayer = instance;
            window.webkit.messageHandlers.playVideo.postMessage(options);
        },

        playAudio(instance, itemsJson, isLocal, mediaSourceJson, startIndex, startPosMs, shuffle, fullscreen) {
            window.MpvAudioPlayer = instance;
            window.webkit.messageHandlers.playAudio.postMessage({
                items: itemsJson,
                isLocal: isLocal,
                mediaSourceJson: mediaSourceJson,
                startIndex: startIndex,
                startPosMs: startPosMs,
                shuffle: shuffle,
                fullscreen: fullscreen,
            });
        },

        sendPlayerCommand(command, arg) {
            window.webkit.messageHandlers.sendMpvCommand.postMessage({
                command: command,
                arg: arg
            });
        },

        queueItems(mediaItemsJson, next) {
            window.webkit.messageHandlers.queueItems.postMessage({
                items: mediaItemsJson,
                next: next
            });
        },

        removeFromPlaylist(index) {
            window.webkit.messageHandlers.removeFromPlaylist.postMessage({
                index: index
            });
        },

        movePlaylistItem(oldIndex, newIndex) {
            window.webkit.messageHandlers.movePlaylistItem.postMessage({
                oldIndex: oldIndex,
                newIndex: newIndex
            });
        },

        destroy() {
            this.sendPlayerCommand('destroyPlayer', null);
        }
    };

    if (!window.EmbyPlayer) {
        window.EmbyPlayer = EmbyPlayer;
    }
});